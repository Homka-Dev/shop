document.getElementById('customForm').addEventListener('submit', function(event) {
	event.preventDefault();
	alert('Form submitted successfully!');
});
